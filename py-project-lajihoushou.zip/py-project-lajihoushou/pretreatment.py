#计外一班-熊卫涛
# 没装环境的需要先装一下环境，pip install  -i https://mirrors.aliyun.com/pypi/simple/ scikit-learn jieba
import re
import jieba
import codecs
import os
# 去掉非中文字符
def clean_str(string):
    string = re.sub(r"[^\u4e00-\u9fff]", " ", string)
    string = re.sub(r"\s{2,}", " ", string)
    return string.strip()



def get_data_in_a_file(original_path, save_path='all_emails.txt'):
    files = os.listdir(original_path)
    for file in files:
        if os.path.isdir(original_path + '/' + file):
                get_data_in_a_file(original_path + '/' + file, save_path=save_path)
        else:
            email = ''
            # 注意要用 'ignore'，不然会报错
            f = codecs.open(original_path + '/' + file, 'r', 'gbk', errors='ignore')
            # lines = f.readlines()
            for line in f:
                line = clean_str(line)
                email += line
            f.close()
           
            f = open(save_path, 'a', encoding='utf8')
            email = [word for word in jieba.cut(email) if word.strip() != '']
            f.write(' '.join(email) + '\n')

def get_label_in_a_file(original_path, save_path='all_emails.txt',flag='0'):
    # 统计文件个数
    count = 0
    for _, _, files in os.walk(original_path):
        count += len(files)
    # 为每个文件写入标签
    label_list = [flag] * count
    f = open(save_path, 'a', encoding='utf8')
    f.write('\n'.join(label_list))
    f.close()



if __name__ == '__main__':
    # step 1
    print('Storing emails in a file ...')
    #这里无论是使用绝对路径还是相对路径都是生成在当前项目文件夹的同一级，不清楚为什么
    #但是建议你修改一下
    #我猜测这里可能是将左边路径里的文件，写入到右边
    get_data_in_a_file('C:/Users/86131/Desktop/VS/PY/py-project-lajihoushou/data/normal', save_path='all_emails.txt')
    get_data_in_a_file('C:/Users/86131/Desktop/VS/PY/py-project-lajihoushou/data/spam', save_path='all_emails.txt')
    print('Store emails finished !')
 
    # step 2
    print('Storing labels in a file ...')
    #这里无论是使用绝对路径还是相对路径都是生成在当前项目文件夹的同一级，不清楚为什么
    #但是建议你修改一下
    #我猜测这里可能是将左边路径里的文件，写入到右边
    get_label_in_a_file('C:/Users/86131/Desktop/VS/PY/py-project-lajihoushou/data/normal', save_path='label.txt',flag='1')
    get_label_in_a_file('C:/Users/86131/Desktop/VS/PY/py-project-lajihoushou/data/spam', save_path='label.txt',flag='0')
    print('Store labels finished !')



####################################################################
########################################################################
#####################################################################