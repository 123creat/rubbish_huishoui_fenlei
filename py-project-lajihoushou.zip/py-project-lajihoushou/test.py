#计外一班-熊卫涛
import jieba
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.svm import SVC
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import accuracy_score
from sklearn.linear_model import LogisticRegression
from sklearn import svm, ensemble, naive_bayes
from sklearn import metrics
import numpy as np
#没有numpy的需要先装一下

def get_data_tf_idf(email_file_name):
    vectoring = TfidfVectorizer(input='content', tokenizer=tokenizer_space, analyzer='word')
    content = open(email_file_name, 'r', encoding='utf8').readlines()
    x = vectoring.fit_transform(content)
    return x, vectoring

def get_label_list(label_file_name):
    with open(label_file_name, 'r', encoding='utf-8') as f:
        label_list = [line.strip() for line in f]  
    return label_list

def tokenizer_space(line):
    return [li for li in line.split() if li.strip() != '']

#这里用的是自己所生成的文件的绝对路径，这样文件的位置固定
np.random.seed(1)
email_file_name = 'C:/Users/86131/Desktop/VS/PY/all_emails.txt'
label_file_name = 'C:/Users/86131/Desktop/VS/PY/label.txt'

x, vectoring = get_data_tf_idf(email_file_name)
y = get_label_list(label_file_name)
index = np.arange(len(y))  
y = np.array(y)
np.random.shuffle(index)
y = y[index]
x = x[index]


x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.15)
clf = svm.LinearSVC()
clf.fit(x_train, y_train)

y_pred = clf.predict(x_test)
print('classification_report\n', metrics.classification_report(y_test, y_pred, digits=4))
print('Accuracy:', metrics.accuracy_score(y_test, y_pred))